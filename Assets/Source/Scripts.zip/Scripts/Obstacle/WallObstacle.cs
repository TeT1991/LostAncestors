public class WallObstacle : Obstacle
{

}
