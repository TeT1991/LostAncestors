public class GroundObstacle : Obstacle { }
