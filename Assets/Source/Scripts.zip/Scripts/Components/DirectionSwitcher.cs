using System;

public class DirectionSwitcher 
{
    private float _direction;

    public float Direction => _direction;

    public Action<float> DirectionChanged;

    public void Init(float direction)
    {
        SetDirection(direction);
    }

    public void SetDirection(float direction)
    {
        if (direction != 0)
        {
            _direction = direction;
            DirectionChanged?.Invoke(_direction);
        }
    }

    public void ReverseDirection()
    {
        _direction = -_direction;
        DirectionChanged?.Invoke(_direction);
    }
}

