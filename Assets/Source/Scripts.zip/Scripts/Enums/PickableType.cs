public enum PickableType 
{
    Health
}
